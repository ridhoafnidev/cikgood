<?php 
	define('DB_USERNAME','root');
	define('DB_PASSWORD','');
	define('DB_NAME','fs_contoh');
    define('DB_HOST','localhost');
    
    //defined a new constant for firebase api key
	define('FIREBASE_API_KEY', 'AAAAhMy03zE:APA91bGL__zqdLXriASweEkwRdUXsVKFtdMpkJYvfZMPWlbmQvDkGJjJZmTOo-jrB_FZGNy7XnHQHwGA0hArsKMIGv93c3bf30TwMwqVruwGiPI-LPzBqzK-1XFSIQ6svOQ1o2BQzurN');

	