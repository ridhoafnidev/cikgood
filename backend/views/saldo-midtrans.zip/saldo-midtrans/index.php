<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Saldo Midtrans';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="saldo-midtrans-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Saldo Midtrans', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'custom_field1',
            'custom_field2',
            'status_code',
            'status_message',
            // 'transaction_id',
            // 'masked_card',
            // 'order_id',
            // 'payment_type',
            // 'transaction_time',
            // 'transaction_status',
            // 'fraud_status',
            // 'approval_code',
            // 'signature_key',
            // 'bank',
            // 'gross_amount',
            // 'channel_response_message',
            // 'card_type',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
