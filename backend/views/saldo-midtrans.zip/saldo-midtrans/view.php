<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\SaldoMidtrans */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Saldo Midtrans', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="saldo-midtrans-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'custom_field1',
            'custom_field2',
            'status_code',
            'status_message',
            'transaction_id',
            'masked_card',
            'order_id',
            'payment_type',
            'transaction_time',
            'transaction_status',
            'fraud_status',
            'approval_code',
            'signature_key',
            'bank',
            'gross_amount',
            'channel_response_message',
            'card_type',
        ],
    ]) ?>

</div>
