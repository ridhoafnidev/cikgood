<?php
/**
 * Created by PhpStorm.
 * User: adryanev
 * Date: 02/10/17
 * Time: 22:35
 */

namespace api\modules\v1;


use yii\web\Response;

class Module extends \yii\base\Module
{

    public function init()
    {
        parent::init();

        // ...  other initialization code ...
    }
}